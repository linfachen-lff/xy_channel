# XY Channel Plugin for OpenClaw

A channel plugin for integrating Xiaoyi (小艺) intelligent assistant with OpenClaw using the A2A (Agent-to-Agent) protocol over dual WebSocket connections.

## Features

- **Dual WebSocket Connection**: Maintains two WebSocket connections for high reliability
- **Session Binding**: First-response server binding with automatic session routing
- **Streaming Support**: Real-time streaming responses with status updates
- **File Handling**: Three-phase file upload and automatic file download
- **Location Tool**: Built-in tool for retrieving user location (WGS84 coordinates)
- **Push Messages**: Support for scheduled/outbound push notifications
- **Heartbeat Management**: Dual-layer heartbeat (application + protocol level)

## Installation

```bash
# Install from local package
openclaw plugins install xy_channel-1.0.0.tgz

# Or from npm (when published)
openclaw plugins install xy_channel
```

## Configuration

### Using CLI Wizard

```bash
openclaw onboard xy
```

The wizard will prompt you for:
- API Key
- User ID (uid)
- Agent ID
- API ID
- Push ID
- WebSocket URLs (with defaults)
- File upload service URL

### Manual Configuration

Add to your `openclaw.json`:

```json
{
  "channels": {
    "xy": {
      "enabled": true,
      "wsUrl1": "ws://localhost:8765/ws/link",
      "wsUrl2": "ws://localhost:8768/ws/link",
      "apiKey": "your_api_key",
      "uid": "your_user_id",
      "agentId": "agent_id",
      "apiId": "api_id",
      "pushId": "push_id",
      "fileUploadUrl": "http://localhost:8767"
    }
  }
}
```

## Usage

### Start the Gateway

```bash
openclaw gateway restart
```

### Check Status

```bash
openclaw gateway status
```

### Send Messages

The XY channel supports:
- Text messages
- Media files (images, videos, audio, documents)
- Location tool calls
- Push notifications

## Architecture

### Core Components

- **WebSocket Manager**: Manages dual WebSocket connections with automatic reconnection
- **Message Dispatcher**: Routes incoming A2A messages to OpenClaw core
- **Reply Dispatcher**: Converts OpenClaw responses to A2A format
- **File Services**: Handles three-phase upload and URL-based download
- **Tool System**: Extensible tool framework with location tool included

### Message Flow

1. **Inbound**: XY Server → WebSocket → Parser → Bot → OpenClaw Core
2. **Outbound**: OpenClaw Core → Reply Dispatcher → Formatter → WebSocket → XY Server

### Session Management

- First message from either server binds the session to that server
- Subsequent messages route to the bound server
- Session bindings cleared on disconnection

## A2A Protocol

The plugin implements the Xiaoyi A2A protocol (JSON-RPC 2.0):

### Request Format

```json
{
  "jsonrpc": "2.0",
  "method": "message",
  "params": {
    "sessionId": "session_123",
    "agentId": "agent_456",
    "message": {
      "messageId": "msg_789",
      "parts": [
        { "kind": "text", "text": "Hello" }
      ]
    }
  },
  "id": "task_001"
}
```

### Response Format

```json
{
  "jsonrpc": "2.0",
  "id": "task_001",
  "result": {
    "taskId": "task_001",
    "kind": "artifact-update",
    "append": false,
    "final": true,
    "artifact": {
      "artifactId": "artifact_uuid",
      "parts": [
        { "kind": "text", "text": "Response" }
      ]
    }
  }
}
```

## Development

### Build

```bash
npm install
npm run build
```

### Pack

```bash
npm pack
```

### Testing

Use the included `pyServer_v4` for local testing:

```bash
cd pyServer_v4
python3 server.py
```

## Troubleshooting

### WebSocket Connection Issues

- Check that both `wsUrl1` and `wsUrl2` are reachable
- Verify firewall settings allow WebSocket connections
- Check logs with `openclaw gateway logs`

### File Upload Failures

- Ensure `fileUploadUrl` is correct
- Verify API key has file upload permissions
- Check file size limits (typically 10MB)

### Location Tool Not Working

- User device must grant location permissions
- Requires `com.huawei.hmos.aidispatchservice` bundle
- 5-second timeout for location retrieval

## License

MIT

## Support

For issues and feature requests, please visit:
https://github.com/your-org/xy_channel/issues
